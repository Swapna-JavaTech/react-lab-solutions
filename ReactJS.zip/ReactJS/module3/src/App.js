import React from "react";
import "./App.css";

import { BrowserRouter, Route, Switch } from "react-router-dom";

import HomePage from "./components/pages/HomePage";
import CustomersPage from "./components/pages/CustomersPage";
import AboutPage from "./components/pages/AboutPage";
import AppNavbar from "./components/pages/AppNavbar";

import CustomerDetails from "./components/customers/CustomerDetails";
import CustomerForm from "./components/customers/CustomerForm";

function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <AppNavbar />
        <br />
        <hr />
        <Switch>
          <Route exact path="/" component={HomePage} />

          <Route exact path="/customers" component={CustomersPage} />
          <Route path="/customers/new" component={CustomerForm} />
          <Route exact path="/customers/:id" component={CustomerDetails} />
          <Route path="/customers/:id/edit" component={CustomerForm} />

          <Route path="/about" component={AboutPage} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
