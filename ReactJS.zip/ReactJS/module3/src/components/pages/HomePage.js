import React, { Component } from "react";

class HomePage extends Component {
  render() {
    return (
      <div className="jumbotron">
        <h1 className="display-5">TopGun Bank - Admin app</h1>
        <p className="lead">A Simple customer management app for the Topguns Bank</p>
        <hr />

        <p>Using the app, the admin can</p>
        <ul>
          <li>
            View the list of customers
          </li>
          <li>
            Create, update and delete customers
          </li>
          <li>
            View customer's account information
          </li>
        </ul>

      </div>
    );
  }
}

export default HomePage;
