import React from "react";
import CustomersList from '../customers/CustomersList';

class CustomersPage extends React.Component {
  render() {
    return (
      <div>
         <CustomersList />
      </div>
    )
  }
}

export default CustomersPage;