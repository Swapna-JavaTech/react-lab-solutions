import React from "react";
import axios from "axios";

import { Link } from "react-router-dom";

class CustomerList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      customers: null,
      selectedCustomer: null,
      errors: false
    };

    this.addCustomer = this.addCustomer.bind(this);
    this.deleteCustomer = this.deleteCustomer.bind(this);
  }

  componentDidMount() {
    axios
      .get("http://localhost:8080/api/customers")
      .then(res => {
        this.setState({ customers: res.data });
      })
      .catch(err => {
        this.setState({ errors: err });
      });
  }

  deleteCustomer(evt, custId) {
    evt.preventDefault();

    // for some reason, delete alone is not working with axios
    // we are getting CSRF token issue
    // but delete works with POSTMAN and also with fetch api
    // so we need to debug and find out why
    // axios
    //   .delete(`https://localhost:8080/api/customers/${custId}`)
    //   .then(res => {
    //     let updatedCustomers = [...this.state.customers].filter(cust => cust.id !== custId);
    //     this.setState({ customers: updatedCustomers });
    //   })
    //   .catch(err => {
    //     alert("Delete unsuccessful : ", err);
    //   });

    fetch(`http://localhost:8080/api/customers/${custId}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    })
      .then(res => {
        console.log("Delete successful");
        let updatedCustomers = [...this.state.customers].filter(
          cust => cust.id !== custId
        );
        this.setState({ customers: updatedCustomers });
      })
      .catch(err => {
        console.log(JSON.stringify(err));
        alert("Delete unsuccessful : ", err);
      });
  }

  tabRow() {
    const tableRows = this.state.customers.map((cust, i) => {
      return (
        <tr key={i}>
          <td> {cust.id} </td>
          <td> {cust.firstName} </td>
          <td> {cust.lastName} </td>
          <td> {cust.email} </td>
          <td>
            <Link className="ui basic blue button" to={`/customers/${cust.id}`}>
              Show
            </Link>
            &nbsp;&nbsp;
            <Link
              className="ui basic blue button"
              to={`/customers/${cust.id}/edit`}
            >
              Edit
            </Link>
            &nbsp;&nbsp;
            <Link
              className="ui basic blue button"
              onClick={e => this.deleteCustomer(e, cust.id)}
            >
              Delete
            </Link>
          </td>
        </tr>
      );
    });

    return tableRows;
  }

  addCustomer(newCustomer) {
    const totalCustomers = this.state.customers.length;
    newCustomer.id = totalCustomers + 1;
    let newList = [...this.state.customers];
    newList.push(newCustomer);
    this.setState({
      customers: newList
    });
  }

  render() {
    return (
      <div>
        <Link color="primary" to="/customers/new">
          Create new customer
        </Link>
        <hr />

        <h4>Customers List</h4>
        <table className="table table-bordered table-sm">
          <thead>
            <tr onSelect={this.showCustomer}>
              <th>Id</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>{this.state.customers ? this.tabRow() : null}</tbody>
        </table>
        <br />
        <br />
      </div>
    );
  }
}

export default CustomerList;
