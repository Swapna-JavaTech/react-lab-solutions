import React from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Redirect } from "react-router-dom";
import classnames from "classnames";

class CustomerForm extends React.Component {
  initialValue = {
    firstName: "",
    lastName: "",
    email: "",
    phone: ""
  };

  constructor(props) {
    super(props);
    this.state = {
      customer: this.initialValue,
      done: false,
      errors: {}
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.validateCustomer = this.validateCustomer.bind(this);
  }

  componentDidMount = () => {
    const custId = this.props.match.params.id;

    if (custId) {
      axios
        .get("http://localhost:8080/api/customers/" + custId)
        .then(res => {
          this.setState({
            customer: res.data
          });
        })
        .catch(err => {
          console.log(err);
        });
    }
  };

  handleChange(evt) {
    const value = evt.target.value;
    const name = evt.target.name;
    let customer = { ...this.state.customer };
    customer[name] = value;
    this.setState({ customer });
  }

  validateCustomer() {
    const newCustomer = this.state.customer;

    let errors = {};
    if (newCustomer.firstName === "")
      errors.firstName = "First Name cant be empty";
    if (newCustomer.lastName === "")
      errors.lastName = "Last Name cant be empty";
    if (newCustomer.email === "") errors.email = "Email cant be empty";

    const noOfErrors = Object.keys(errors).length;
    let isFormValid = false;
    noOfErrors === 0 ? (isFormValid = true) : (isFormValid = false);

    this.setState({
      errors: errors
    });
    return isFormValid;
  }

  handleSubmit(evt) {
    evt.preventDefault();
    const customer = this.state.customer;

    const isFormValid = this.validateCustomer();

    // submit the form only if its valid, else the errors will showup
    if (isFormValid) {
      if (customer.id) {
        const custId = customer.id;
        axios
          .put("http://localhost:8080/api/customers/" + custId, customer)
          .then(res => {
            this.setState({ done: true });
          })
          .catch(err => {
            this.setState({ errors: err });
          });
      } else {
        axios
          .post("http://localhost:8080/api/customers", customer)
          .then(res => {
            this.setState({ done: true });
          })
          .catch(err => {
            this.setState({ errors: err });
          });
      }
    }
  }

  getCustForm() {
    const custForm = (
      <form onSubmit={this.handleSubmit} noValidate>
      
        <div
          className={classnames("form-group", {
            "has-error": !!this.state.errors.firstName
          })}
        >
          <label>First Name</label>
          <input
            type="text"
            name="firstName"
            className="form-control"
            value={this.state.customer.firstName}
            onChange={this.handleChange}
          />
          <span className="help-block">{this.state.errors.firstName}</span>
        </div>

        <div
          className={classnames("form-group", {
            "has-error": !!this.state.errors.lastName
          })}
        >
          <label>Last Name</label>
          <input
            type="text"
            name="lastName"
            className="form-control"
            value={this.state.customer.lastName}
            onChange={this.handleChange}
          />
          <span className="help-block">{this.state.errors.lastName}</span>
        </div>
        <div
          className={classnames("form-group", {
            "has-error": !!this.state.errors.email
          })}
        >
          <label>Email</label>
          <input
            type="text"
            name="email"
            className="form-control"
            value={this.state.customer.email}
            onChange={this.handleChange}
          />
          <span className="help-block">{this.state.errors.email}</span>
        </div>
        <div className="form-group">
          <label>Phone</label>
          <input
            type="text"
            name="phone"
            className="form-control"
            value={this.state.customer.phone}
            onChange={this.handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
    );

    return custForm;
  }

  render() {
    const backLinkText = "< Back to Customers List";
    const formTitle = (
      <h2>{this.state.customer.id ? "Edit Customer" : "Add Customer"}</h2>
    );

    return (
      <div>
        <div className="row">
          <Link color="primary" to="/customers">
            {backLinkText}
          </Link>
        </div>
        <hr />
        <div className="row">
          <div className="col-md-6">
            <h5>{formTitle}</h5>
            {this.state.done ? (
              <Redirect to={`/customers`} />
            ) : (
              this.getCustForm()
            )}
          </div>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default CustomerForm;
