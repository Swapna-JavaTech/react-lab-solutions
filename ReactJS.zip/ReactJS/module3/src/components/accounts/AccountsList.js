import React from "react";
import axios from "axios";

class AccountsList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      accounts: null
    };
  }

  componentDidMount() {
    axios
      .get(
        "http://localhost:8080/api/customers/" +
          this.props.customerId +
          "/accounts"
      )
      .then(res => {
        this.setState({
          accounts: res.data
        });
      });
  }

  tabRow() {
    const tableRows = this.state.accounts.map((acct, i) => {
      return (
        <tr key={i}>
          <td> {acct.accountNumber} </td>
          <td> {acct.accountType} </td>
          <td> {acct.accountBranch} </td>
          <td> {acct.accountBalance} </td>
        </tr>
      );
    });

    return tableRows;
  }

  render() {
    return (
      <div>
        <h4>List of Accounts</h4>
        <table className="table table-bordered table-sm">
          <thead>
            <tr>
              <th>Account No</th>
              <th>Type</th>
              <th>Branch</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>{this.state.accounts ? this.tabRow() : null}</tbody>
        </table>
      </div>
    );
  }
}

export default AccountsList;
