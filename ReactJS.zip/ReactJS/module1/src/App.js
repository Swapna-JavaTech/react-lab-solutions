import React from 'react';
import './App.css';
import HelloWorld from './components/HelloWorld';
import HelloMessage from './components/HelloMessage';
import Counter from './components/Counter';
import Alert from './components/Alert';

function App() {
  return (
    <div className="App">
      <h3>UseCase 1 - Components, Props and States</h3>
      <hr/>
      <HelloWorld />

      <h4>Single Prop</h4>
      <HelloMessage name="Euler" />
      <h4>Multiple Props</h4>
      <HelloMessage name="Ramanujam" message="I got this in my dreams" />


      <h4>State and Virtual DOM</h4>
      <Counter />
      <h4>Interactive Component - Event Handling</h4>
      <Alert />
    </div>
  );
}

export default App;
